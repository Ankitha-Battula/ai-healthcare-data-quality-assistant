# Two-minute video presentation script

Personalize this script to reflect what you actually built and the AI tools you actually used. Do not claim features or testing you did not perform.

**0:00–0:15 — Introduction**
Hello, my name is [Your Name]. My project is the AI-Powered Healthcare Data Quality Assistant. It helps users review a synthetic patient CSV and identify common data-quality issues before further analysis.

**0:15–0:35 — Problem and solution**
Healthcare datasets can contain blank fields, repeated rows, or values that need review. This demo shows a preview, summary metrics, missing values by column, and a table of detected issues. It does not diagnose patients or automatically change clinical data.

**0:35–0:55 — Tools**
I used [name the AI tools you actually used] to help plan the solution, draft or review code, and prepare documentation. I used Python, Pandas, and Streamlit for the application, and GitHub to share the project.

**0:55–1:15 — Prompt engineering**
I started with a prompt that defined the user problem, beginner-friendly tools, synthetic data, and safety limitations. I then refined the request to include CSV upload, missing-value checks, duplicate detection, age validation, and downloadable reports. I checked the generated suggestions rather than accepting them blindly. [Mention your actual prompt revisions.]

**1:15–1:45 — Live demo**
Here is the sample CSV. The app reports six rows and four columns. It identifies blank cells, an exact duplicate row, and an age value of 150 for review under the demo rule. I can inspect the issue table and download the report. [Show the app and verify the numbers on screen.]

**1:45–2:00 — Challenges and conclusion**
One challenge was making the checks clear without silently changing data. I kept the original rows, showed issues for human review, and added a privacy warning to use synthetic data only. This project demonstrates a practical, transparent data-quality workflow. Thank you.

## Recording checklist
- Run the app before recording.
- Show the app, sample data, issue table, and download option.
- Mention only AI tools you actually used.
- Keep the video at least two minutes.
- Upload the video to Drive and test the link in a private/incognito window.
