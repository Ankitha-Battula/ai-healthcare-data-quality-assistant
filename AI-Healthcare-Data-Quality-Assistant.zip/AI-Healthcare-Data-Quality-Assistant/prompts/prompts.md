# Prompt Documentation — Healthcare Data Quality Assistant

**Important:** This file is a starter prompt log. Replace or edit it to match the prompts you actually used and the results you observed. Do not submit prompts as “used” if you did not actually use them.

## Prompt 1 — Plan the project

> I am a beginner building a project for an AI Growth & Automation Associate assessment. Propose a small, working Healthcare or Technology project that demonstrates practical problem-solving. Keep the scope achievable in Python and Streamlit. Use only synthetic patient data, avoid clinical diagnosis, and include a visible output that can be demonstrated in a two-minute video. List the features, files, setup steps, and limitations.

**What I checked:** Is the scope achievable? Does it produce a working deliverable rather than only an idea?

## Prompt 2 — Generate the first version

> Create a beginner-friendly Streamlit application in Python that accepts a CSV of synthetic patient data and checks for missing values, exact duplicate rows, non-numeric ages, and ages outside a configurable demo range of 0–120. Show row/column counts, a table of issues, and download buttons for the issue report and reviewed CSV. Do not automatically delete records or invent missing clinical values. Include clear privacy and non-clinical-use warnings. Provide requirements.txt and instructions to run locally.

**What I checked:** I reviewed the code, ran it locally, and compared the output against the sample data.

## Prompt 3 — Improve reliability (use only if you actually asked it)

> Review this CSV validation app for beginner-level bugs. Pay special attention to blank strings, missing values, optional Age columns, non-numeric age values, duplicate detection, and clear error messages when a CSV cannot be read. Suggest minimal fixes and explain each change.

**What to record after trying it:** Write down which suggestions you accepted or rejected and why.

## Prompt 4 — Improve the interface (use only if you actually asked it)

> Improve the Streamlit interface for a short recruiter demo. Keep the app simple and accessible. Show clear summary metrics, a preview table, per-column missing counts, a readable issue report, and CSV downloads. Keep the privacy warning visible and avoid claiming that the app uses an AI model at runtime unless it actually does.

**What to record after trying it:** Note the UI changes that you implemented.

## Prompt 5 — Test the result

> Create a small synthetic CSV test dataset that contains one exact duplicate row, at least one missing value, and one age outside 0–120. Tell me the expected results so I can verify the app. Do not include real patient information.

**Observed test results:** Fill this in after running the app. Example expected outcome for `sample_patients.csv`: 6 rows, 4 columns, 3 missing cells (Priya's Age appears twice and Sana's City is blank), 1 exact duplicate row, and 1 age value flagged for review (150).

## Final reflection

- AI tool(s) actually used:
- What I changed after the first result:
- One issue I found and fixed:
- How I verified the output:
- What I would improve next:
