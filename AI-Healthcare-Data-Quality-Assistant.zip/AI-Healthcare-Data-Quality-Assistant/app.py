import io
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Healthcare Data Quality Assistant", page_icon="🩺", layout="wide")

st.title("🩺 AI-Powered Healthcare Data Quality Assistant")
st.write(
    "Upload a patient CSV to identify common data-quality issues. "
    "This demo uses rule-based checks; AI tools were used during development. "
    "It is not a clinical decision-support system."
)

st.info(
    "Privacy note: Use only synthetic/demo data. Do not upload real patient records, "
    "personal identifiers, or protected health information."
)

DEFAULT_CSV = """PatientID,Name,Age,City
101,Ravi,35,Hyderabad
102,Priya,,Bengaluru
102,Priya,,Bengaluru
103,Kumar,150,Chennai
104,Sana,28,
105,Arun,42,Visakhapatnam
"""

def inspect_data(df: pd.DataFrame):
    """Return a cleaned display copy and data-quality issue summary."""
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]

    # Treat empty strings and whitespace-only strings as missing values.
    df = df.replace(r"^\s*$", pd.NA, regex=True)

    missing_by_column = df.isna().sum()
    duplicate_mask = df.duplicated(keep="first")
    duplicate_count = int(duplicate_mask.sum())

    issues = []
    for idx, row in df.iterrows():
        row_number = idx + 2  # CSV header is line 1
        missing_cols = [col for col in df.columns if pd.isna(row[col])]
        if missing_cols:
            issues.append({
                "CSV row": row_number,
                "Issue": "Missing value",
                "Column": ", ".join(missing_cols),
                "Details": "One or more fields are blank."
            })

    if "Age" in df.columns:
        age_numeric = pd.to_numeric(df["Age"], errors="coerce")
        for idx, value in age_numeric.items():
            if pd.notna(value) and (value < 0 or value > 120):
                issues.append({
                    "CSV row": idx + 2,
                    "Issue": "Age outside demo range",
                    "Column": "Age",
                    "Details": f"Age value {value:g} is outside the configured 0–120 range; review it."
                })
            elif pd.notna(df.loc[idx, "Age"]) and pd.isna(value):
                issues.append({
                    "CSV row": idx + 2,
                    "Issue": "Non-numeric age",
                    "Column": "Age",
                    "Details": f"Age value {df.loc[idx, 'Age']!s} could not be interpreted as a number."
                })

    duplicate_rows = df.loc[duplicate_mask].copy()
    for idx in duplicate_rows.index:
        issues.append({
            "CSV row": idx + 2,
            "Issue": "Exact duplicate row",
            "Column": "All columns",
            "Details": "This row exactly matches an earlier row; review before removing."
        })

    issues_df = pd.DataFrame(issues, columns=["CSV row", "Issue", "Column", "Details"])
    summary = {
        "rows": int(len(df)),
        "columns": int(len(df.columns)),
        "missing_cells": int(df.isna().sum().sum()),
        "duplicate_rows": duplicate_count,
        "age_review_flags": int(
            ((pd.to_numeric(df["Age"], errors="coerce") < 0) |
             (pd.to_numeric(df["Age"], errors="coerce") > 120)).fillna(False).sum()
        ) if "Age" in df.columns else 0,
    }
    return df, missing_by_column, issues_df, summary, duplicate_mask

with st.sidebar:
    st.header("Data input")
    uploaded_file = st.file_uploader("Upload a CSV file", type=["csv"])
    st.caption("Expected example columns: PatientID, Name, Age, City")
    if st.button("Load demo dataset", use_container_width=True):
        st.session_state["use_demo"] = True

if uploaded_file is not None:
    try:
        source_df = pd.read_csv(uploaded_file)
        st.success(f"Loaded uploaded file: {uploaded_file.name}")
    except Exception as exc:
        st.error(f"Could not read this CSV. Check the file format. Details: {exc}")
        st.stop()
elif st.session_state.get("use_demo", False):
    source_df = pd.read_csv(io.StringIO(DEFAULT_CSV))
    st.caption("Showing the built-in synthetic demo dataset.")
else:
    source_df = pd.read_csv(io.StringIO(DEFAULT_CSV))
    st.caption("Showing the built-in synthetic demo dataset. Upload your own synthetic CSV from the sidebar.")

if source_df.empty:
    st.warning("The CSV has no data rows.")
    st.stop()

checked_df, missing_by_column, issues_df, summary, duplicate_mask = inspect_data(source_df)

st.subheader("Data quality overview")
c1, c2, c3, c4 = st.columns(4)
c1.metric("Rows", summary["rows"])
c2.metric("Columns", summary["columns"])
c3.metric("Missing cells", summary["missing_cells"])
c4.metric("Exact duplicate rows", summary["duplicate_rows"])

st.subheader("Preview")
st.dataframe(checked_df, use_container_width=True, hide_index=True)

left, right = st.columns(2)
with left:
    st.subheader("Missing values by column")
    missing_df = missing_by_column.rename_axis("Column").reset_index(name="Missing count")
    st.dataframe(missing_df, use_container_width=True, hide_index=True)
with right:
    st.subheader("Validation rules")
    st.markdown(
        "- Blank or whitespace-only cells are flagged as missing.\n"
        "- Exact duplicate rows are flagged for review.\n"
        "- If an `Age` column exists, values below 0 or above 120 are flagged.\n"
        "- Non-numeric age values are flagged.\n"
        "- The app reports issues; it does not silently alter the source data."
    )

st.subheader("Issues found")
if issues_df.empty:
    st.success("No issues were found by the configured checks.")
else:
    st.dataframe(issues_df, use_container_width=True, hide_index=True)
    st.download_button(
        "Download issue report (CSV)",
        data=issues_df.to_csv(index=False).encode("utf-8"),
        file_name="healthcare_data_quality_issues.csv",
        mime="text/csv",
    )

st.subheader("Download reviewed dataset")
st.write("Download the input data with blank cells normalized to missing values. No rows are automatically deleted.")
st.download_button(
    "Download normalized dataset (CSV)",
    data=checked_df.to_csv(index=False).encode("utf-8"),
    file_name="healthcare_data_quality_review.csv",
    mime="text/csv",
)

st.caption(
    "Demo limitations: checks are simple configurable rules, not medical advice. "
    "Always verify findings with a data owner before changing or deleting records."
)
