# AI-Powered Healthcare Data Quality Assistant

A beginner-friendly Streamlit demo that checks a **synthetic patient CSV** for common data-quality issues:
- Missing values
- Exact duplicate rows
- Age values outside a configurable demo range (0–120)
- Non-numeric age values
- Downloadable issue report and reviewed CSV

> **Important:** This is a data-quality demonstration, not a clinical tool. Use only synthetic/demo data. Do not upload real patient records or protected health information. Findings should be reviewed by a data owner before any changes are made.

## How AI was used

AI tools (for example, ChatGPT or another coding assistant) can help plan the app, draft code, explain errors, and improve documentation. In this repository, the actual data checks are implemented as transparent Python/Pandas rules; the app does not claim to call an AI model at runtime.

When submitting your assessment, accurately name the AI tools you actually used and keep your actual prompts in `prompts/prompts.md`. Do not claim to have used a tool or feature you did not use.

## Run locally

1. Install Python 3.10 or newer.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Create a virtual environment (recommended):
   - Windows: `py -m venv .venv`
   - Activate: `.venv\Scripts\activate`
   - macOS/Linux: `python3 -m venv .venv`
5. Install dependencies: `pip install -r requirements.txt`
6. Start the app: `streamlit run app.py`
7. Open the local URL shown in the terminal (usually `http://localhost:8501`).

## Test it

- The app opens with a built-in synthetic sample.
- Or upload `sample_patients.csv` using the sidebar.
- Confirm it reports missing cells, one exact duplicate row, and the age value `150` for review.
- Download the issue report and normalized dataset.

## Files

- `app.py` — Streamlit application and rule-based checks
- `sample_patients.csv` — synthetic sample data
- `requirements.txt` — Python dependencies
- `prompts/prompts.md` — prompt log template and example iteration flow
- `video_demo_script.md` — suggested two-minute presentation script
- `screenshots/` — place your own screenshots here after running the app

## Scope and limitations

- Duplicate detection checks exact duplicate rows, not necessarily duplicate people.
- The age range is a demo validation rule, not a medical judgment.
- Blank cells are reported, not automatically filled.
- The app does not diagnose patients and should not be used for real clinical decisions.
